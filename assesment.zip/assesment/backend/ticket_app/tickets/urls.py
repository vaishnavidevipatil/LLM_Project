from django.urls import path
from .views import TicketListCreateView, TicketUpdateView, TicketStatsView, TicketClassifyView
from .views import root_view
urlpatterns = [
    path('', root_view),  # root path
    path('tickets/', TicketListCreateView.as_view(), name='ticket-list-create'),
    path('tickets/<int:pk>/', TicketUpdateView.as_view(), name='ticket-update'),
    path('tickets/stats/', TicketStatsView.as_view(), name='ticket-stats'),
    path('tickets/classify/', TicketClassifyView, name='ticket-classify'),
]
