import requests

API_URL = "https://api-inference.huggingface.co/models/google/flan-t5-base"
headers = {"Authorization": "Bearer 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"}

def classify_ticket(text):
    prompt = f"""
Classify this support ticket.

Return JSON like:
category: billing/technical/account/general
priority: low/medium/high/critical

Ticket: {text}
"""

    response = requests.post(API_URL, headers=headers, json={"inputs": prompt})
    return response.json()

print(classify_ticket("I cannot login to my account"))
