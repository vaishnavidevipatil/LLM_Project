from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Count
from tickets.models import Ticket
from .serializers import TicketSerializer
import tickets.models as models
from django.http import JsonResponse

import openai
from rest_framework.decorators import api_view
from rest_framework.response import Response

# List + Create Tickets

# Initialize client with API key
client = openai.OpenAI(api_key="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")
# openai.api_key = "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"
class TicketListCreateView(generics.ListCreateAPIView):
    queryset = Ticket.objects.all().order_by('-created_at')
    serializer_class = TicketSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        category = self.request.query_params.get('category')
        priority = self.request.query_params.get('priority')
        status_param = self.request.query_params.get('status')
        search = self.request.query_params.get('search')

        if category:
            queryset = queryset.filter(category=category)
        if priority:
            queryset = queryset.filter(priority=priority)
        if status_param:
            queryset = queryset.filter(status=status_param)
        if search:
            queryset = queryset.filter(
                models.Q(title__icontains=search) | models.Q(description__icontains=search)
            )
        return queryset

# Update Ticket (PATCH)
class TicketUpdateView(generics.UpdateAPIView):
    queryset = Ticket.objects.all()
    serializer_class = TicketSerializer

# Stats endpoint
class TicketStatsView(APIView):
    def get(self, request):
        data = {
            'total_tickets': Ticket.objects.count(),
            'by_category': Ticket.objects.values('category').annotate(count=Count('id')),
            'by_priority': Ticket.objects.values('priority').annotate(count=Count('id')),
            'by_status': Ticket.objects.values('status').annotate(count=Count('id')),
        }
        return Response(data)

# LLM classify endpoint
# class TicketClassifyView(APIView):
#     def post(self, request):
#         description = request.data.get('description', '')
#         # For demo, we’ll return dummy suggestions
#         suggested_category = 'technical'  # Replace with actual LLM API call
#         suggested_priority = 'medium'     # Replace with actual LLM API call

#         return Response({
#             'category': suggested_category,
#             'priority': suggested_priority
#         }, status=status.HTTP_200_OK)

# from rest_framework.decorators import api_view
# from rest_framework.response import Response
import os
import requests

@api_view(["POST"])
def TicketClassifyView(request):
    description = request.data.get("description", "").lower()

    if not description:
        return Response({"error": "Description required"}, status=400)

    # =========================
    # TRY REAL LLM (optional)
    # =========================
    HF_TOKEN = os.getenv("HF_TOKEN")

    if HF_TOKEN:
        try:
            API_URL = "https://router.huggingface.co/hf-inference/models/google/flan-t5-small"
            headers = {"Authorization": f"Bearer {HF_TOKEN}"}

            prompt = f"""
Classify support ticket.

Return JSON:
category: billing/technical/account/general
priority: low/medium/high/critical

Ticket: {description}
"""

            r = requests.post(API_URL, headers=headers, json={"inputs": prompt}, timeout=5)

            if r.status_code == 200:
                return Response({"llm_response": r.json()})

        except:
            pass  # fallback to mock

    # =========================
    # MOCK LLM (ALWAYS WORKS)
    # =========================
    if "payment" in description or "refund" in description:
        return Response({"category": "billing", "priority": "high"})

    if "login" in description or "account" in description:
        return Response({"category": "account", "priority": "medium"})

    if "error" in description or "bug" in description:
        return Response({"category": "technical", "priority": "high"})

    return Response({"category": "general", "priority": "low"})




def root_view(request):
    return JsonResponse({"message": "Welcome to the Support Ticket System API"})