import { useState } from "react";
import API from "../api";

export default function TicketForm({ refresh }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [priority, setPriority] = useState("");

  const classify = async () => {
    const res = await API.post("tickets/classify/", { description });
    setCategory(res.data.category);
    setPriority(res.data.priority);
  };

  const submitTicket = async () => {
    await API.post("tickets/", {
      title,
      description,
      category,
      priority,
    });

    setTitle("");
    setDescription("");
    refresh();
  };

  return (
    <div>
      <h2>Create Ticket</h2>

      <input
        placeholder="title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <textarea
        placeholder="description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <button onClick={classify}>Auto classify</button>

      <p>Category: {category}</p>
      <p>Priority: {priority}</p>

      <button onClick={submitTicket}>Submit</button>
    </div>
  );
}
