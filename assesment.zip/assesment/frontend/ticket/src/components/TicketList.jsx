import { useEffect, useState } from "react";
import API from "../api";

export default function TicketList() {
  const [tickets, setTickets] = useState([]);

  const loadTickets = async () => {
    const res = await API.get("tickets/");
    setTickets(res.data);
  };

  useEffect(() => {
    loadTickets();
  }, []);

  return (
    <div>
      <h2>All Tickets</h2>

      {tickets.map((t) => (
        <div key={t.id}>
          <h4>{t.title}</h4>
          <p>{t.description}</p>
          <p>
            {t.category} | {t.priority}
          </p>
        </div>
      ))}
    </div>
  );
}
