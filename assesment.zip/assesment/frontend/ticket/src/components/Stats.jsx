import { useEffect, useState } from "react";
import API from "../api";

export default function Stats() {
  const [stats, setStats] = useState({});

  useEffect(() => {
    API.get("tickets/stats/").then((res) => setStats(res.data));
  }, []);

  return (
    <div>
      <h2>Status</h2>
      <pre>{JSON.stringify(stats, null, 2)}</pre>
    </div>
  );
}
