import TicketForm from "./components/TicketForm";
import TicketList from "./components/TicketList";
import Stats from "./components/Stats";

function App() {
  return (
    <div>
      <h1>Ticket System</h1>
      <TicketForm />
      <TicketList />
      <Stats />
    </div>
  );
}

export default App;
