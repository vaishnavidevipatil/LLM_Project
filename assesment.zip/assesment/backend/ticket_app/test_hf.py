import requests

HF_TOKEN = "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"

API_URL = "https://router.huggingface.co/hf-inference/models/google/flan-t5-base"

headers = {
    "Authorization": f"Bearer {HF_TOKEN}",
    "Content-Type": "application/json"
}

payload = {
    "inputs": "Classify this ticket: I cannot login to my account"
}

response = requests.post(API_URL, headers=headers, json=payload)

print(response.status_code)
print(response.text)
